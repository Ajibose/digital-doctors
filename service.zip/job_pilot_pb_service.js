// package: jobpilot
// file: job_pilot.proto

var job_pilot_pb = require("./job_pilot_pb");
var google_protobuf_empty_pb = require("google-protobuf/google/protobuf/empty_pb");
var grpc = require("@improbable-eng/grpc-web").grpc;

var JobPilotService = (function () {
  function JobPilotService() {}
  JobPilotService.serviceName = "jobpilot.JobPilotService";
  return JobPilotService;
}());

JobPilotService.BuildAvatar = {
  methodName: "BuildAvatar",
  service: JobPilotService,
  requestStream: false,
  responseStream: false,
  requestType: job_pilot_pb.BuildAvatarRequest,
  responseType: job_pilot_pb.BuildAvatarResponse
};

JobPilotService.SearchJobs = {
  methodName: "SearchJobs",
  service: JobPilotService,
  requestStream: false,
  responseStream: false,
  requestType: job_pilot_pb.SearchJobsRequest,
  responseType: job_pilot_pb.SearchJobsResponse
};

JobPilotService.HealthCheck = {
  methodName: "HealthCheck",
  service: JobPilotService,
  requestStream: false,
  responseStream: false,
  requestType: google_protobuf_empty_pb.Empty,
  responseType: job_pilot_pb.HealthResponse
};

JobPilotService.GetDemoPersona = {
  methodName: "GetDemoPersona",
  service: JobPilotService,
  requestStream: false,
  responseStream: false,
  requestType: google_protobuf_empty_pb.Empty,
  responseType: job_pilot_pb.DemoPersonaResponse
};

exports.JobPilotService = JobPilotService;

function JobPilotServiceClient(serviceHost, options) {
  this.serviceHost = serviceHost;
  this.options = options || {};
}

JobPilotServiceClient.prototype.buildAvatar = function buildAvatar(requestMessage, metadata, callback) {
  if (arguments.length === 2) {
    callback = arguments[1];
  }
  var client = grpc.unary(JobPilotService.BuildAvatar, {
    request: requestMessage,
    host: this.serviceHost,
    metadata: metadata,
    transport: this.options.transport,
    debug: this.options.debug,
    onEnd: function (response) {
      if (callback) {
        if (response.status !== grpc.Code.OK) {
          var err = new Error(response.statusMessage);
          err.code = response.status;
          err.metadata = response.trailers;
          callback(err, null);
        } else {
          callback(null, response.message);
        }
      }
    }
  });
  return {
    cancel: function () {
      callback = null;
      client.close();
    }
  };
};

JobPilotServiceClient.prototype.searchJobs = function searchJobs(requestMessage, metadata, callback) {
  if (arguments.length === 2) {
    callback = arguments[1];
  }
  var client = grpc.unary(JobPilotService.SearchJobs, {
    request: requestMessage,
    host: this.serviceHost,
    metadata: metadata,
    transport: this.options.transport,
    debug: this.options.debug,
    onEnd: function (response) {
      if (callback) {
        if (response.status !== grpc.Code.OK) {
          var err = new Error(response.statusMessage);
          err.code = response.status;
          err.metadata = response.trailers;
          callback(err, null);
        } else {
          callback(null, response.message);
        }
      }
    }
  });
  return {
    cancel: function () {
      callback = null;
      client.close();
    }
  };
};

JobPilotServiceClient.prototype.healthCheck = function healthCheck(requestMessage, metadata, callback) {
  if (arguments.length === 2) {
    callback = arguments[1];
  }
  var client = grpc.unary(JobPilotService.HealthCheck, {
    request: requestMessage,
    host: this.serviceHost,
    metadata: metadata,
    transport: this.options.transport,
    debug: this.options.debug,
    onEnd: function (response) {
      if (callback) {
        if (response.status !== grpc.Code.OK) {
          var err = new Error(response.statusMessage);
          err.code = response.status;
          err.metadata = response.trailers;
          callback(err, null);
        } else {
          callback(null, response.message);
        }
      }
    }
  });
  return {
    cancel: function () {
      callback = null;
      client.close();
    }
  };
};

JobPilotServiceClient.prototype.getDemoPersona = function getDemoPersona(requestMessage, metadata, callback) {
  if (arguments.length === 2) {
    callback = arguments[1];
  }
  var client = grpc.unary(JobPilotService.GetDemoPersona, {
    request: requestMessage,
    host: this.serviceHost,
    metadata: metadata,
    transport: this.options.transport,
    debug: this.options.debug,
    onEnd: function (response) {
      if (callback) {
        if (response.status !== grpc.Code.OK) {
          var err = new Error(response.statusMessage);
          err.code = response.status;
          err.metadata = response.trailers;
          callback(err, null);
        } else {
          callback(null, response.message);
        }
      }
    }
  });
  return {
    cancel: function () {
      callback = null;
      client.close();
    }
  };
};

exports.JobPilotServiceClient = JobPilotServiceClient;

