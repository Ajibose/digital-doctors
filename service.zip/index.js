import React, { useState } from "react";
import StyledButton from "@integratedComponents/StyledButton";
import OutlinedTextArea from "@commonComponents/OutlinedTextArea";
import * as jobPilot_pb from "./job_pilot_pb.js";
import { JobPilotService } from "./job_pilot_pb_service.js";
import "./style.css";

/* ---------------- Job Card ---------------- */

const JobCard = ({ job }) => {
  const formatSalary = (min, max) => {
    if (!min && !max) return null;
    const formatter = new Intl.NumberFormat('en-GB', {
      style: 'currency',
      currency: 'GBP',
      maximumFractionDigits: 0
    });
    
    if (min === max) return formatter.format(min);
    return `${formatter.format(min)} - ${formatter.format(max)}`;
  };

  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 0) return "Today";
    if (diffDays === 1) return "Yesterday";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    return date.toLocaleDateString('en-GB', { month: 'short', day: 'numeric' });
  };

  const getPriorityColor = (priority) => {
    switch (priority?.toLowerCase()) {
      case 'high': return '#2e7d32';
      case 'medium': return '#f57c00';
      case 'low': return '#757575';
      default: return '#666';
    }
  };

  const getCategoryColor = (category) => {
    switch (category?.toLowerCase()) {
      case 'exceptional': return { bg: '#e8f5e9', text: '#2e7d32' };
      case 'strong': return { bg: '#e3f2fd', text: '#1565c0' };
      case 'good': return { bg: '#fff3e0', text: '#e65100' };
      default: return { bg: '#f5f5f5', text: '#666' };
    }
  };

  const salary = formatSalary(job.salary_min, job.salary_max);
  const categoryColors = getCategoryColor(job.match_category);

  return (
    <a
      href={job.url}
      target="_blank"
      rel="noopener noreferrer"
      className="job-card"
    >
      {/* Header Section */}
      <div className="job-card-header">
        <div className="job-header-left">
          <h5 className="job-title">{job.title}</h5>
          <div className="job-company-info">
            <span className="company-name">{job.company}</span>
            <span className="separator">•</span>
            <span className="location">{job.location}</span>
          </div>
        </div>
        <div className="job-header-right">
          <div 
            className="match-score-badge"
            style={{ 
              background: categoryColors.bg, 
              color: categoryColors.text 
            }}
          >
            <div className="score-number">{job.match_score}%</div>
            <div className="score-label">{job.match_category}</div>
          </div>
        </div>
      </div>

      {/* Salary & Date */}
      <div className="job-meta-info">
        {salary && (
          <div className="meta-item">
            <span className="meta-icon">💰</span>
            <span className="meta-text">{salary}</span>
          </div>
        )}
        {job.created && (
          <div className="meta-item">
            <span className="meta-icon">📅</span>
            <span className="meta-text">Posted {formatDate(job.created)}</span>
          </div>
        )}
      </div>

      {/* Why Suggested */}
      <div className="job-section">
        <div className="section-title">Why this matches you</div>
        <p className="job-why">{job.why_suggested}</p>
      </div>

      {/* Key Highlights */}
      {job.key_highlights?.length > 0 && (
        <div className="job-section">
          <div className="section-title">Key Highlights</div>
          <ul className="job-highlights">
            {job.key_highlights.map((highlight, i) => (
              <li key={i}>{highlight}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Skills Needed */}
      {job.skills_needed?.length > 0 && (
        <div className="job-section">
          <div className="section-title">Required Skills</div>
          <div className="skills-container">
            {job.skills_needed.map((skill, i) => (
              <span key={i} className="skill-tag">{skill}</span>
            ))}
          </div>
        </div>
      )}

      {/* Potential Concerns */}
      {job.potential_concerns?.length > 0 && (
        <div className="job-section concerns-section">
          <div className="section-title">Things to Consider</div>
          <ul className="job-concerns">
            {job.potential_concerns.map((concern, i) => (
              <li key={i}>{concern}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Score Breakdown */}
      {job.score_breakdown && (
        <div className="job-section">
          <div className="section-title-small">Match Breakdown</div>
          <div className="score-breakdown">{job.score_breakdown}</div>
        </div>
      )}

      {/* Footer */}
      <div className="job-footer">
        <div className="footer-left">
          <span 
            className="priority-badge"
            style={{ color: getPriorityColor(job.application_priority) }}
          >
            <span className="priority-dot">●</span>
            {job.application_priority} Priority
          </span>
        </div>
        <div className="footer-right">
          <span className="apply-cta">
            View & Apply
            <span className="arrow">→</span>
          </span>
        </div>
      </div>
    </a>
  );
};

/* ---------------- Main UI ---------------- */

const ServiceUI = ({ serviceClient }) => {
  const [persona, setPersona] = useState("");
  const [resumeFile, setResumeFile] = useState(null);
  const [extraContext, setExtraContext] = useState("");
  const [jobs, setJobs] = useState([]);
  const [loading, setLoading] = useState(false);

  const buildAvatar = () => {
    if (!resumeFile) {
      alert("Please upload a resume file");
      return;
    }

    setLoading(true);
    const reader = new FileReader();

    reader.onload = (e) => {
      try {
        const bytes = new Uint8Array(e.target.result);
        const request = new jobPilot_pb.BuildAvatarRequest();

        request.setResumeFile(bytes);
        request.setFilename(resumeFile.name);
        request.setExtraContext(extraContext);

        serviceClient.unary(JobPilotService.BuildAvatar, {
          request,
          onEnd: (res) => {
            setLoading(false);
            if (res.status !== 0) {
              alert(`Error: ${res.statusMessage}`);
              return;
            }
            setPersona(res.message.getPersonaJson());
          },
        });
      } catch (err) {
        setLoading(false);
        console.error(err);
        alert("Client error while building avatar");
      }
    };

    reader.onerror = () => {
      setLoading(false);
      alert("Failed to read file");
    };

    reader.readAsArrayBuffer(resumeFile);
  };

  const searchJobs = () => {
    if (!persona) {
      alert("Build an avatar first");
      return;
    }

    setLoading(true);
    const request = new jobPilot_pb.SearchJobsRequest();

    request.setPersona(persona);
    request.setStaticResponses("");
    request.setDynamicResponses("");
    request.setMode("default");
    request.setRegion("");

    serviceClient.unary(JobPilotService.SearchJobs, {
      request,
      onEnd: (res) => {
        setLoading(false);
        if (res.status !== 0) {
          alert(`Error: ${res.statusMessage}`);
          return;
        }

        try {
          const parsed = JSON.parse(res.message.getResultJson());
          if (!parsed.jobs || !Array.isArray(parsed.jobs)) {
            throw new Error("Invalid job response format");
          }
          setJobs(parsed.jobs);
        } catch (err) {
          console.error("Invalid job JSON:", err);
          alert("Service returned invalid job data");
        }
      },
    });
  };

  return (
    <div className="service-container">
      <div className="service-header">
        <h2>Job Pilot</h2>
        <p>
          Upload your resume to create an AI persona and find matching jobs.
        </p>
      </div>

      <div className="content-box">
        <h4>Step 1: Build Avatar</h4>

        <label className="file-label">
          Resume (PDF/DOCX):
          <input
            type="file"
            accept=".pdf,.doc,.docx"
            onChange={(e) => setResumeFile(e.target.files[0])}
          />
        </label>

        <OutlinedTextArea
          label="Extra Context"
          placeholder="Describe your career goals or specific skills..."
          value={extraContext}
          onChange={(e) => setExtraContext(e.target.value)}
          rows={3}
        />

        <StyledButton
          btnText={loading && !persona ? "Processing..." : "Build Avatar"}
          onClick={buildAvatar}
          disabled={loading || !resumeFile}
        />

        {persona && <div className="success-badge">✓ Persona Created</div>}
      </div>

      <div className={`content-box ${!persona ? "disabled-step" : ""}`}>
        <h4>Step 2: Search Jobs</h4>

        <StyledButton
          btnText={loading ? "Searching..." : "Search Jobs"}
          onClick={searchJobs}
          disabled={!persona || loading}
        />

        {jobs.length > 0 && (
          <div className="results-container">
            <div className="results-header">
              <h5>Found {jobs.length} Matching Jobs</h5>
              <p className="results-subtext">
                Sorted by match score • Click any card to apply
              </p>
            </div>

            <div className="jobs-grid">
              {jobs.map((job) => (
                <JobCard key={job.id} job={job} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ServiceUI;