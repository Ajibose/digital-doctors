import React, { useState } from "react";
import StyledButton from "@integratedComponents/StyledButton";
import * as digitalDoctors_pb from "./digital-doctors_pb.js";
import { DigitalDoctorsAssistantService } from "./digital-doctors_pb_service.js";
import { Empty } from "google-protobuf/google/protobuf/empty_pb";
import "./style.css";

const pb = digitalDoctors_pb;

/* ── Result Display ─────────────────────────────────────────────── */
const ResultDisplay = ({ data, type }) => {
  if (!data) return null;

  if (type === "risk") {
    const level = data.prediction?.toUpperCase();
    const levelClass =
      level === "HIGH"
        ? "level-high"
        : level === "MEDIUM"
          ? "level-medium"
          : "level-low";
    return (
      <div className="result-panel">
        <div className="result-header">Assessment Result</div>
        <div className="result-body">
          <div className={`risk-level ${levelClass}`}>
            <span className="risk-icon">
              {level === "HIGH" ? "⚠" : level === "MEDIUM" ? "◈" : "✓"}
            </span>
            <div>
              <div className="risk-label">Risk Level</div>
              <div className="risk-value">{data.prediction}</div>
            </div>
          </div>
          <div className="metrics-row">
            <div className="metric">
              <div className="metric-num">
                {(data.confidence * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Confidence</div>
            </div>
            <div className="metric">
              <div className="metric-num">
                {(data.probabilities?.high * 100).toFixed(1)}%
              </div>
              <div className="metric-label">High Risk</div>
            </div>
            <div className="metric">
              <div className="metric-num">
                {(data.probabilities?.medium * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Medium Risk</div>
            </div>
            <div className="metric">
              <div className="metric-num">
                {(data.probabilities?.low * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Low Risk</div>
            </div>
          </div>
          {data.warning && (
            <div className="result-warning">⚠ {data.warning}</div>
          )}
          <div className="result-model">Model: {data.model}</div>
        </div>
      </div>
    );
  }

  if (type === "treatment") {
    const success = data.prediction === 1;
    return (
      <div className="result-panel">
        <div className="result-header">Treatment Outcome</div>
        <div className="result-body">
          <div className={`risk-level ${success ? "level-low" : "level-high"}`}>
            <span className="risk-icon">{success ? "✓" : "✕"}</span>
            <div>
              <div className="risk-label">Predicted Outcome</div>
              <div className="risk-value">
                {success ? "Treatment Successful" : "Treatment May Fail"}
              </div>
            </div>
          </div>
          <div className="metrics-row">
            <div className="metric">
              <div className="metric-num">
                {(data.successProbability * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Success Prob.</div>
            </div>
            <div className="metric">
              <div className="metric-num">
                {(data.confidence * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Confidence</div>
            </div>
            <div className="metric">
              <div className="metric-num">
                {(data.probabilities?.success * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Success %</div>
            </div>
            <div className="metric">
              <div className="metric-num">
                {(data.probabilities?.failure * 100).toFixed(1)}%
              </div>
              <div className="metric-label">Failure %</div>
            </div>
          </div>
          <div className="result-model">Model: {data.model}</div>
        </div>
      </div>
    );
  }

  return null;
};

/* ── Main Component ─────────────────────────────────────────────── */
const MedicalAssistantUI = ({ serviceClient }) => {
  const [activeTab, setActiveTab] = useState("risk");

  /* Risk state */
  const [riskForm, setRiskForm] = useState({
    age: "",
    bmi: "",
    systolic: "",
    diastolic: "",
    severity: "",
    chronic: "",
  });
  const [riskResult, setRiskResult] = useState(null);
  const [riskLoading, setRiskLoading] = useState(false);

  /* Treatment state */
  const [treatmentForm, setTreatmentForm] = useState({
    age: "",
    severity: "",
    compliance: "",
    medication: "",
    condition: "",
  });
  const [treatmentResult, setTreatmentResult] = useState(null);
  const [treatmentLoading, setTreatmentLoading] = useState(false);

  /* ── Predict Risk ── */
  const predictRisk = () => {
    setRiskLoading(true);
    setRiskResult(null);
    const request = new pb.PredictRiskRequest();
    request.setAge(Number(riskForm.age));
    request.setBmi(Number(riskForm.bmi));
    request.setSystolicBp(Number(riskForm.systolic));
    request.setDiastolicBp(Number(riskForm.diastolic));
    request.setSeverityScore(Number(riskForm.severity));
    request.setChronicConditions(riskForm.chronic);
    serviceClient.unary(DigitalDoctorsAssistantService.PredictRisk, {
      request,
      onEnd: (res) => {
        setRiskLoading(false);
        if (res.status !== 0) {
          alert(res.statusMessage);
          return;
        }
        setRiskResult(res.message.toObject());
      },
    });
  };

  /* ── Predict Treatment ── */
  const predictTreatment = () => {
    setTreatmentLoading(true);
    setTreatmentResult(null);
    const request = new pb.PredictTreatmentRequest();
    request.setPatientAge(Number(treatmentForm.age));
    request.setSeverityScore(Number(treatmentForm.severity));
    request.setComplianceRate(Number(treatmentForm.compliance));
    request.setMedication(treatmentForm.medication);
    request.setCondition(treatmentForm.condition);
    serviceClient.unary(DigitalDoctorsAssistantService.PredictTreatment, {
      request,
      onEnd: (res) => {
        setTreatmentLoading(false);
        if (res.status !== 0) {
          alert(res.statusMessage);
          return;
        }
        setTreatmentResult(res.message.toObject());
      },
    });
  };

  return (
    <div className="service-container">
      {/* ── Header ── */}
      <div className="app-header">
        <div className="app-header-left">
          <div className="app-logo">✦</div>
          <div>
            <h1 className="app-title">Digital Doctors</h1>
            <p className="app-subtitle">Clinical AI Assistant</p>
          </div>
        </div>
        <div className="app-header-right">
          <span className="app-tag">ML-Powered</span>
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="tab-bar">
        <button
          className={`tab-btn ${activeTab === "risk" ? "active" : ""}`}
          onClick={() => setActiveTab("risk")}
        >
          <span className="tab-icon">🫀</span>
          Risk Prediction
        </button>
        <button
          className={`tab-btn ${activeTab === "treatment" ? "active" : ""}`}
          onClick={() => setActiveTab("treatment")}
        >
          <span className="tab-icon">💊</span>
          Treatment Outcome
        </button>
      </div>

      {/* ── Risk Tab ── */}
      {activeTab === "risk" && (
        <div className="tab-panel">
          <div className="panel-intro">
            <div className="panel-intro-text">
              <h3>Cardiovascular Risk Assessment</h3>
              <p>
                Predict patient risk level from clinical vitals and patient
                history
              </p>
            </div>
          </div>

          <div className="fields-section">
            <div className="fields-group">
              <div className="fields-group-label">Vitals</div>
              <div className="fields-grid">
                <div className="field-wrap">
                  <label>
                    Age <span className="unit">yrs</span>
                  </label>
                  <input
                    type="number"
                    placeholder="45"
                    value={riskForm.age}
                    onChange={(e) =>
                      setRiskForm({ ...riskForm, age: e.target.value })
                    }
                  />
                </div>
                <div className="field-wrap">
                  <label>
                    BMI <span className="unit">kg/m²</span>
                  </label>
                  <input
                    type="number"
                    placeholder="28.5"
                    value={riskForm.bmi}
                    onChange={(e) =>
                      setRiskForm({ ...riskForm, bmi: e.target.value })
                    }
                  />
                </div>
                <div className="field-wrap">
                  <label>
                    Systolic BP <span className="unit">mmHg</span>
                  </label>
                  <input
                    type="number"
                    placeholder="140"
                    value={riskForm.systolic}
                    onChange={(e) =>
                      setRiskForm({ ...riskForm, systolic: e.target.value })
                    }
                  />
                </div>
                <div className="field-wrap">
                  <label>
                    Diastolic BP <span className="unit">mmHg</span>
                  </label>
                  <input
                    type="number"
                    placeholder="90"
                    value={riskForm.diastolic}
                    onChange={(e) =>
                      setRiskForm({ ...riskForm, diastolic: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>

            <div className="fields-group">
              <div className="fields-group-label">Clinical</div>
              <div className="fields-grid">
                <div className="field-wrap">
                  <label>
                    Severity <span className="unit">0–10</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    placeholder="3"
                    value={riskForm.severity}
                    onChange={(e) =>
                      setRiskForm({ ...riskForm, severity: e.target.value })
                    }
                  />
                </div>
                <div className="field-wrap field-span">
                  <label>Chronic Conditions</label>
                  <input
                    type="text"
                    placeholder="hypertension"
                    value={riskForm.chronic}
                    onChange={(e) =>
                      setRiskForm({ ...riskForm, chronic: e.target.value })
                    }
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="action-row">
            <StyledButton
              btnText={riskLoading ? "Analyzing…" : "Run Risk Assessment"}
              onClick={predictRisk}
              disabled={riskLoading}
            />
            {riskLoading && (
              <span className="loading-text">Processing clinical data…</span>
            )}
          </div>

          <ResultDisplay data={riskResult} type="risk" />
        </div>
      )}

      {/* ── Treatment Tab ── */}
      {activeTab === "treatment" && (
        <div className="tab-panel">
          <div className="panel-intro">
            <div className="panel-intro-text">
              <h3>Treatment Outcome Prediction</h3>
              <p>
                Estimate treatment success probability based on patient profile
                and medication
              </p>
            </div>
          </div>

          <div className="fields-section">
            <div className="fields-group">
              <div className="fields-group-label">Patient Profile</div>
              <div className="fields-grid">
                <div className="field-wrap">
                  <label>
                    Patient Age <span className="unit">yrs</span>
                  </label>
                  <input
                    type="number"
                    placeholder="60"
                    value={treatmentForm.age}
                    onChange={(e) =>
                      setTreatmentForm({
                        ...treatmentForm,
                        age: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="field-wrap">
                  <label>
                    Severity <span className="unit">0–10</span>
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="10"
                    placeholder="4"
                    value={treatmentForm.severity}
                    onChange={(e) =>
                      setTreatmentForm({
                        ...treatmentForm,
                        severity: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="field-wrap">
                  <label>
                    Compliance <span className="unit">0–1</span>
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    min="0"
                    max="1"
                    placeholder="0.8"
                    value={treatmentForm.compliance}
                    onChange={(e) =>
                      setTreatmentForm({
                        ...treatmentForm,
                        compliance: e.target.value,
                      })
                    }
                  />
                </div>
              </div>
            </div>

            <div className="fields-group">
              <div className="fields-group-label">Treatment</div>
              <div className="fields-grid">
                <div className="field-wrap">
                  <label>Medication</label>
                  <input
                    type="text"
                    placeholder="Metformin"
                    value={treatmentForm.medication}
                    onChange={(e) =>
                      setTreatmentForm({
                        ...treatmentForm,
                        medication: e.target.value,
                      })
                    }
                  />
                </div>
                <div className="field-wrap field-span">
                  <label>Condition</label>
                  <input
                    type="text"
                    placeholder="Type 2 Diabetes"
                    value={treatmentForm.condition}
                    onChange={(e) =>
                      setTreatmentForm({
                        ...treatmentForm,
                        condition: e.target.value,
                      })
                    }
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="action-row">
            <StyledButton
              btnText={
                treatmentLoading ? "Analyzing…" : "Predict Treatment Outcome"
              }
              onClick={predictTreatment}
              disabled={treatmentLoading}
            />
            {treatmentLoading && (
              <span className="loading-text">Processing treatment data…</span>
            )}
          </div>

          <ResultDisplay data={treatmentResult} type="treatment" />
        </div>
      )}
    </div>
  );
};

export default MedicalAssistantUI;
